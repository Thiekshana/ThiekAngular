﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MyAngularProject.Models;

namespace MyAngularProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        private readonly AngularContext _context;

        public CustomerController(AngularContext context)
        {
            _context = context;
        }

        [HttpGet, Authorize(Roles = "Administrator")]
        public async Task<ActionResult<IEnumerable<Users>>> GetUsers()
        {
            Users user = new Users();
            return await _context.Users.ToListAsync();
        }

    }
}
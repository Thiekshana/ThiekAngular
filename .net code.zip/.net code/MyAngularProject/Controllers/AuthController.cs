﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using MyAngularProject.Models;

namespace MyAngularProject.Controllers
{
 

    [Route("api/auth")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly AngularContext _context;

        public AuthController(AngularContext context)
        {
            _context = context;
        }

        int uId;
        string uRoleName;

        [HttpPost, Route("login")]

        public IActionResult Login([FromBody] LoginModel user)
         {


            getUserData(user);

            if (user==null)
            {
                return BadRequest("Invalid Client Request");
            }

            if(user.UserName == "thiek" && user.Password == "thiek123")
            {
                var secretKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("this is my custom Secret key for authnetication"));
                var signingCredentials = new SigningCredentials(secretKey, SecurityAlgorithms.HmacSha256);

                var timeNow = DateTime.Now.ToLocalTime().AddMinutes(5);

                var tokenOptions = new JwtSecurityToken(
                    issuer: "http://localhost:5000",
                    audience: "http://localhost:5000",
                    claims: new List<Claim>{
                        new Claim(ClaimTypes.Name, user.UserName),
                        new Claim(ClaimTypes.Role, uRoleName)
                    },
                    expires: DateTime.Now.ToLocalTime().AddMinutes(5),
                    signingCredentials: signingCredentials
                    );

                var tokenString = new JwtSecurityTokenHandler().WriteToken(tokenOptions);
                return Ok(new { token = tokenString });

            }

            return Unauthorized();
        }

        public void getUserData(LoginModel loggedinUser)
        {

            uId = _context.Users.Where(x => x.FirstName == loggedinUser.UserName).Where(y => y.Password == loggedinUser.Password).Select(uId => uId.Id).FirstOrDefault();

            uRoleName = _context.Roles.Where(r => r.Id == _context.UserRoles
            .Where(r => r.Id == uId).Select(uRoleId => uRoleId.Id).FirstOrDefault())
            .Select(urName => urName.Name).FirstOrDefault();


        }
    }
}
 
﻿using System;
using System.Collections.Generic;

namespace MyAngularProject.Models
{
    public partial class Posts
    {
        public int PostId { get; set; }
        public string Heading { get; set; }
        public string Img { get; set; }
        public int UserId { get; set; }
        public string Description { get; set; }
    }
}
